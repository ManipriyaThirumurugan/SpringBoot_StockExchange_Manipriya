package com.example.SpringBoot.Model;

public class Sector {

}
